# Recipe Finder & Meal Planner

Final project skeleton, upgraded from midterm.

- Uses your midterm UI (CSS + images)
- Adds PHP + MySQL login/register
- Guest mode with localStorage
- Recipe search with culture/diet filters
- Weekly meal planner stored in localStorage
- Ingredient cart stored in DB for logged-in users
- Imports localStorage data into DB after login
