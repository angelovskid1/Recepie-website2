<?php
require_once 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$userId = (int) $_SESSION['user_id'];

$favCount = $pdo->query("SELECT COUNT(*) AS c FROM favorites WHERE user_id = $userId")
                ->fetch()['c'] ?? 0;
$listCount = $pdo->query("SELECT COUNT(*) AS c FROM ingredients_shopping_list WHERE user_id = $userId")
                 ->fetch()['c'] ?? 0;
?>
<!DOCTYPE html>
<head>
  <title>Your Profile</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'partials/nav.php'; ?>
<main class="section">
  <h1>Profile</h1>
  <p><strong>Username:</strong> <?php echo htmlspecialchars($_SESSION['username']); ?></p>
  <p><strong>Saved recipes:</strong> <?php echo (int)$favCount; ?></p>
  <p><strong>Ingredients in list:</strong> <?php echo (int)$listCount; ?></p>
</main>
</body>
</html>
